# KABURU (కబురు)

KABURU is a hyperlocal Telugu news Android application built using Flutter 3+. It delivers GPS-based Telugu news with rich media content such as images and short-form videos. The app supports OTP-based login via Firebase, offline caching, push notifications, and has an admin web portal for managing news content.

---

## Key Features

- GPS-driven hyperlocal news feed based on user's current city.
- News categories: Politics, Entertainment, Jobs, Sports, Technology, Health, Business, Education, Local.
- OTP-based phone number authentication using Firebase Authentication.
- Firebase Firestore backend for news content.
- Firebase Storage for hosting media (images/videos).
- Push notifications via Firebase Messaging.
- Roman-to-Telugu transliteration integrated in text inputs.
- Short-form video and image news stories with smooth playback.
- Offline-first caching of news for seamless reading without internet.
- Clean, modern UI in grey and pink theme.
- Animated splash screen with KABURU (కబురు) logo.
- Bottom navigation with Home, Categories, Videos, Saved, Profile tabs.
- Admin access via a Firebase web portal link accessible from profile screen.
- Compatible with Android 10, 11, 12, 13, 14.

---

## Setup and Installation

### Prerequisites

- Install Flutter SDK 3.x or higher. Follow the instructions here: [Flutter installation](https://flutter.dev/docs/get-started/install)
- Install Android Studio or IntelliJ IDEA with Flutter & Dart plugins.
- An Android device or emulator running Android 10 or higher.
- Firebase project configured for KABURU app with:
  - Android app registration (provide your package name)
  - Firebase Authentication enabled (Phone sign-in)
  - Firestore database created
  - Firebase Storage bucket configured
  - Firebase Cloud Messaging enabled

---

### Steps

1. Clone/download this repository.

2. Navigate to the project folder:

   