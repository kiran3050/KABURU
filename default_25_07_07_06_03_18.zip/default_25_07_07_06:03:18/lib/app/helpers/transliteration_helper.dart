class TransliterationHelper {
  // Simple Roman-to-Telugu transliteration map for demo.
  // For production use, integrate an API or a more complete package.

  static const Map<String, String> _map = {
    'a': 'అ',
    'aa': 'ఆ',
    'i': 'ఇ',
    'ii': 'ఈ',
    'u': 'ఉ',
    'uu': 'ఊ',
    'e': 'ఎ',
    'ee': 'ఏ',
    'ai': 'ఐ',
    'o': 'ఒ',
    'oo': 'ఓ',
    'au': 'ఔ',
    'ka': 'క',
    'kha': 'ఖ',
    'ga': 'గ',
    'gha': 'ఘ',
    'nga': 'ఙ',
    'ca': 'చ',
    'cha': 'ఛ',
    'ja': 'జ',
    'jha': 'ఝ',
    'nya': 'ఞ',
    'ta': 'ట',
    'tha': 'ఠ',
    'da': 'డ',
    'dha': 'ఢ',
    'na': 'ణ',
    'pa': 'ప',
    'pha': 'ఫ',
    'ba': 'బ',
    'bha': 'భ',
    'ma': 'మ',
    'ya': 'య',
    'ra': 'ర',
    'la': 'ల',
    'va': 'వ',
    'sha': 'శ',
    'ssa': 'ష',
    'sa': 'స',
    'ha': 'హ',
    'laa': 'ళ',
  };

  String transliterate(String input) {
    String output = input.toLowerCase();
    _map.forEach((key, value) {
      output = output.replaceAll(key, value);
    });
    return output;
  }
}
