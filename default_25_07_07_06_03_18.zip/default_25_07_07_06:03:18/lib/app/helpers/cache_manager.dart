import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/news_item.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CacheManager {
  static const String _cachedNewsKey = 'cached_news';

  Future<void> cacheNews(List<NewsItem> newsItems) async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> encodedNews = newsItems.map((item) => jsonEncode(_newsItemToMap(item))).toList();
    await prefs.setStringList(_cachedNewsKey, encodedNews);
  }

  Future<List<NewsItem>> getCachedNews() async {
    final prefs = await SharedPreferences.getInstance();
    final encodedNews = prefs.getStringList(_cachedNewsKey);
    if (encodedNews == null) return <NewsItem>[];
    final newsItems = encodedNews.map((e) => _newsItemFromMap(jsonDecode(e))).toList();
    return newsItems;
  }

  Map<String, dynamic> _newsItemToMap(NewsItem item) {
    return {
      'id': item.id,
      'title': item.title,
      'content': item.content,
      'category': item.category,
      'latitude': item.latitude,
      'longitude': item.longitude,
      'city': item.city,
      'mediaUrls': item.mediaUrls,
      'isVideo': item.isVideo,
      'timestamp': (item.timestamp as Timestamp).toDate().toIso8601String(),
    };
  }

  NewsItem _newsItemFromMap(Map<String, dynamic> map) {
    return NewsItem(
      id: map['id'],
      title: map['title'],
      content: map['content'],
      category: map['category'],
      latitude: map['latitude'],
      longitude: map['longitude'],
      city: map['city'],
      mediaUrls: List<String>.from(map['mediaUrls']),
      isVideo: map['isVideo'],
      timestamp: Timestamp.fromDate(DateTime.parse(map['timestamp'])),
    );
  }
}
