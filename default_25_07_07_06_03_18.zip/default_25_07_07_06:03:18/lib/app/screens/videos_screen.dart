import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import '../models/news_item.dart';
import '../services/firestore_service.dart';
import '../constants/colors.dart';
import '../widgets/bottom_nav_bar.dart';

class VideosScreen extends StatefulWidget {
  const VideosScreen({Key? key}) : super(key: key);

  @override
  State<VideosScreen> createState() => _VideosScreenState();
}

class _VideosScreenState extends State<VideosScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  List<NewsItem> _videos = [];
  bool _loading = true;
  int _currentIndex = 2;

  @override
  void initState() {
    super.initState();
    _firestoreService.getVideoNewsStream().listen((videos) {
      setState(() {
        _videos = videos;
        _loading = false;
      });
    });
  }

  void _onNavTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    switch (index) {
      case 0:
        Navigator.of(context).pushReplacementNamed('/home');
        break;
      case 1:
        Navigator.of(context).pushReplacementNamed('/categories');
        break;
      case 3:
        Navigator.of(context).pushReplacementNamed('/saved');
        break;
      case 4:
        Navigator.of(context).pushReplacementNamed('/profile');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('వీడియోలు'),
        centerTitle: true,
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onNavTapped,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _videos.isEmpty
              ? const Center(
                  child: Text(
                    'వీడియోలు లభించలేదు',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  itemCount: _videos.length,
                  itemBuilder: (context, index) {
                    final videoItem = _videos[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                      child: VideoListItem(newsItem: videoItem),
                    );
                  },
                ),
    );
  }
}

class VideoListItem extends StatefulWidget {
  final NewsItem newsItem;
  const VideoListItem({Key? key, required this.newsItem}) : super(key: key);

  @override
  State<VideoListItem> createState() => _VideoListItemState();
}

class _VideoListItemState extends State<VideoListItem> {
  late VideoPlayerController _videoPlayerController;
  ChewieController? _chewieController;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    if (widget.newsItem.mediaUrls.isNotEmpty) {
      _videoPlayerController = VideoPlayerController.network(widget.newsItem.mediaUrls.first)
        ..initialize().then((_) {
          _chewieController = ChewieController(
            videoPlayerController: _videoPlayerController,
            autoPlay: false,
            looping: false,
            aspectRatio: _videoPlayerController.value.aspectRatio,
          );
          setState(() {
            _isInitialized = true;
          });
        });
    }
  }

  @override
  void dispose() {
    _chewieController?.dispose();
    _videoPlayerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.newsItem.title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'TeluguOne',
            color: AppColors.darkGrey,
          ),
        ),
        const SizedBox(height: 8),
        _isInitialized && _chewieController != null
            ? Chewie(controller: _chewieController!)
            : Container(
                height: 200,
                color: AppColors.cardGrey,
                child: const Center(child: CircularProgressIndicator()),
              ),
        const SizedBox(height: 16),
      ],
    );
  }
}
