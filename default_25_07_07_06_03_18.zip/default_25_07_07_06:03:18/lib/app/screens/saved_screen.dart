import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/news_item.dart';
import '../constants/colors.dart';
import '../widgets/news_card.dart';
import '../routes.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({Key? key}) : super(key: key);

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  List<NewsItem> _savedNews = [];
  bool _loading = true;

  static const String savedKey = 'saved_news';

  @override
  void initState() {
    super.initState();
    _loadSavedNews();
  }

  Future<void> _loadSavedNews() async {
    setState(() {
      _loading = true;
    });
    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList(savedKey) ?? [];
    final newsList = savedList.map((e) => NewsItem.fromMap(jsonDecode(e))).toList();

    setState(() {
      _savedNews = newsList;
      _loading = false;
    });
  }

  void _onNewsTap(NewsItem item) {
    Navigator.of(context).pushNamed(Routes.fullNews, arguments: item);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('సేవ్ చేసినవి'),
        centerTitle: true,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _savedNews.isEmpty
              ? const Center(
                  child: Text('మీకు సేవ్ చేసిన వార్తలు లేవు',
                      style: TextStyle(fontFamily: 'TeluguOne', fontSize: 16, color: Colors.grey)),
                )
              : ListView.builder(
                  itemCount: _savedNews.length,
                  itemBuilder: (_, index) {
                    final newsItem = _savedNews[index];
                    return NewsCard(
                      newsItem: newsItem,
                      onTap: () => _onNewsTap(newsItem),
                    );
                  },
                ),
    );
  }
}

extension NewsItemExtension on NewsItem {
  static NewsItem fromMap(Map<String, dynamic> map) {
    return NewsItem(
      id: map['id'],
      title: map['title'],
      content: map['content'],
      category: map['category'],
      latitude: map['latitude'],
      longitude: map['longitude'],
      city: map['city'],
      mediaUrls: List<String>.from(map['mediaUrls']),
      isVideo: map['isVideo'],
      timestamp: map['timestamp'] is String
          ? Timestamp.fromDate(DateTime.parse(map['timestamp']))
          : map['timestamp'],
    );
  }
}
