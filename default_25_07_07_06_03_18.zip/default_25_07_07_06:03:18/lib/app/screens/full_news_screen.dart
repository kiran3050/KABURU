import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/news_item.dart';
import '../constants/colors.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class FullNewsScreen extends StatefulWidget {
  final NewsItem newsItem;

  const FullNewsScreen({Key? key, required this.newsItem}) : super(key: key);

  @override
  State<FullNewsScreen> createState() => _FullNewsScreenState();
}

class _FullNewsScreenState extends State<FullNewsScreen> {
  late List<String> mediaUrls;
  int _currentMediaIndex = 0;
  List<VideoPlayerController?> _videoControllers = [];
  List<ChewieController?> _chewieControllers = [];
  bool _isVideo = false;

  @override
  void initState() {
    super.initState();
    mediaUrls = widget.newsItem.mediaUrls;
    _isVideo = widget.newsItem.isVideo;
    for (var url in mediaUrls) {
      if (_isVideo) {
        final controller = VideoPlayerController.network(url);
        _videoControllers.add(controller);
        controller.initialize().then((_) {
          setState(() {});
        });
        final chewieController = ChewieController(videoPlayerController: controller, autoPlay: false, looping: false);
        _chewieControllers.add(chewieController);
      } else {
        _videoControllers.add(null);
        _chewieControllers.add(null);
      }
    }
  }

  @override
  void dispose() {
    for (var chewie in _chewieControllers) {
      chewie?.dispose();
    }
    for (var controller in _videoControllers) {
      controller?.dispose();
    }
    super.dispose();
  }

  void _shareNews() {
    Share.share('${widget.newsItem.title}\n\n${widget.newsItem.content}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('వార్త పూర్తి'),
        actions: [
          IconButton(onPressed: _shareNews, icon: const Icon(Icons.share)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (mediaUrls.isNotEmpty)
            CarouselSlider.builder(
              itemCount: mediaUrls.length,
              options: CarouselOptions(
                height: 250,
                enlargeCenterPage: true,
                enableInfiniteScroll: false,
                onPageChanged: (index, reason) {
                  setState(() {
                    _currentMediaIndex = index;
                  });
                },
              ),
              itemBuilder: (context, index, realIndex) {
                if (_isVideo) {
                  if (_chewieControllers[index] != null && _videoControllers[index]?.value.isInitialized == true) {
                    return Chewie(controller: _chewieControllers[index]!);
                  } else {
                    return Container(
                      height: 250,
                      color: AppColors.cardGrey,
                      child: const Center(child: CircularProgressIndicator()),
                    );
                  }
                } else {
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CachedNetworkImage(
                      imageUrl: mediaUrls[index],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorWidget: (context, url, error) => const Icon(Icons.error),
                    ),
                  );
                }
              },
            ),
          if (mediaUrls.isNotEmpty)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: mediaUrls.asMap().entries.map((entry) {
                return Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _currentMediaIndex == entry.key ? AppColors.pink : AppColors.lightGrey,
                  ),
                );
              }).toList(),
            ),
          const SizedBox(height: 16),
          Text(
            widget.newsItem.title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFamily: 'TeluguOne',
              color: AppColors.darkGrey,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.newsItem.content,
            style: const TextStyle(
              fontSize: 16,
              fontFamily: 'TeluguOne',
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'తేదీ: ${widget.newsItem.timestamp.toDate()}',
            style: const TextStyle(
              fontSize: 12,
              fontFamily: 'TeluguOne',
              color: AppColors.lightGrey,
            ),
          ),
          // Bookmark functionality would go here (not implemented fully here)
        ],
      ),
    );
  }
}
