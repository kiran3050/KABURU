import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';
import '../models/news_item.dart';
import '../services/firestore_service.dart';
import '../services/location_service.dart';
import '../helpers/cache_manager.dart';
import '../widgets/news_card.dart';
import '../widgets/bottom_nav_bar.dart';
import '../routes.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  final LocationService _locationService = LocationService();
  final CacheManager _cacheManager = CacheManager();

  String _city = '';
  List<String> _selectedCategories = [];
  List<NewsItem> _newsItems = [];
  bool _loading = true;
  bool _offline = false;

  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _initAndFetchNews();
  }

  Future<void> _initAndFetchNews() async {
    setState(() {
      _loading = true;
    });
    try {
      final connectivityResult = await Connectivity().checkConnectivity();
      if (connectivityResult == ConnectivityResult.none) {
        _offline = true;
        final cachedNews = await _cacheManager.getCachedNews();
        setState(() {
          _newsItems = cachedNews;
          _loading = false;
        });
        return;
      }
      _offline = false;
      final position = await _locationService.getCurrentPosition();
      final city = await _locationService.getCityNameFromPosition(position);
      _city = city;

      if (_city.isEmpty) {
        setState(() {
          _loading = false;
          _newsItems = [];
        });
        return;
      }

      _firestoreService
          .getNewsStreamByCityAndCategories(_city, _selectedCategories)
          .listen((news) {
        setState(() {
          _newsItems = news;
          _loading = false;
        });
        _cacheManager.cacheNews(news);
      });
    } catch (_) {
      setState(() {
        _loading = false;
        _newsItems = [];
      });
    }
  }

  Future<void> _refresh() async {
    await _initAndFetchNews();
  }

  void _onNewsTap(NewsItem item) {
    Navigator.of(context).pushNamed(Routes.fullNews, arguments: item);
  }

  void _onNavTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    // Handle navigation to other screens
    switch (index) {
      case 0:
        // Already on Home
        break;
      case 1:
        Navigator.of(context).pushNamed('/categories');
        break;
      case 2:
        Navigator.of(context).pushNamed('/videos');
        break;
      case 3:
        Navigator.of(context).pushNamed('/saved');
        break;
      case 4:
        Navigator.of(context).pushNamed('/profile');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.appName),
        centerTitle: true,
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onNavTapped,
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _newsItems.isEmpty
                ? Center(
                    child: Text(
                      _offline
                          ? 'ఆఫ్‌లైన్‌లో వార్తలు అందుబాటులో లేవు'
                          : 'వార్తలు లభించలేదు',
                      style: const TextStyle(
                          fontSize: 16,
                          fontFamily: 'TeluguOne',
                          color: AppColors.lightGrey),
                    ),
                  )
                : ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: _newsItems.length,
                    itemBuilder: (_, index) {
                      final newsItem = _newsItems[index];
                      return NewsCard(
                        newsItem: newsItem,
                        onTap: () => _onNewsTap(newsItem),
                      );
                    },
                  ),
      ),
    );
  }
}
