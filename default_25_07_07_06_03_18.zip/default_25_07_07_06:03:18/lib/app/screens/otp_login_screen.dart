import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/colors.dart';
import '../constants/strings.dart';
import '../services/firebase_auth_service.dart';

class OTPLoginScreen extends StatefulWidget {
  const OTPLoginScreen({Key? key}) : super(key: key);

  @override
  State<OTPLoginScreen> createState() => _OTPLoginScreenState();
}

class _OTPLoginScreenState extends State<OTPLoginScreen> {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();

  bool _codeSent = false;
  String? _verificationId;
  bool _loading = false;
  String? _error;

  void _sendOtp() async {
    final phone = _phoneController.text.trim();
    if (phone.isEmpty || !phone.startsWith('+') || phone.length < 10) {
      setState(() {
        _error = 'సరైన ఫోన్ నెంబరు నమోదు చేయండి';
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });

    final authService = Provider.of<FirebaseAuthService>(context, listen: false);
    await authService.sendOtp(
      phone,
      (verificationId) {
        setState(() {
          _loading = false;
          _codeSent = true;
          _verificationId = verificationId;
        });
      },
      (errorMessage) {
        setState(() {
          _loading = false;
          _error = errorMessage;
        });
      },
    );
  }

  void _verifyOtp() async {
    final otp = _otpController.text.trim();
    if (otp.length != 6) {
      setState(() {
        _error = 'OTP 6 అంకెలు ఉండాలి';
      });
      return;
    }
    if (_verificationId == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final authService = Provider.of<FirebaseAuthService>(context, listen: false);
    try {
      final user = await authService.verifyOtp(_verificationId!, otp);
      if (user != null) {
        // Success: Stream in main.dart AuthenticationWrapper will rebuild to home
      }
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'OTP ధృవీకరణ విఫలం';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.greyBackground,
      appBar: AppBar(
        title: Text(AppStrings.appName),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  _codeSent ? AppStrings.enterOtp : AppStrings.enterPhoneNumber,
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'TeluguOne'),
                ),
                const SizedBox(height: 30),
                TextField(
                  controller: _codeSent ? _otpController : _phoneController,
                  keyboardType: TextInputType.phone,
                  maxLength: _codeSent ? 6 : null,
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    labelText: _codeSent ? AppStrings.enterOtp : AppStrings.enterPhoneNumber,
                  ),
                ),
                const SizedBox(height: 16),
                if (_error != null)
                  Text(_error!, style: const TextStyle(color: Colors.red)),
                if (_loading)
                  const CircularProgressIndicator()
                else
                  ElevatedButton(
                    onPressed: _codeSent ? _verifyOtp : _sendOtp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.pink,
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(
                      _codeSent ? AppStrings.verifyOtp : AppStrings.sendOtp,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
