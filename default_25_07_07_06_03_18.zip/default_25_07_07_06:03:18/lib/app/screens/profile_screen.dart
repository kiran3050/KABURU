import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/colors.dart';
import '../constants/strings.dart';
import '../services/firebase_auth_service.dart';
import '../models/user.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  Future<void> _launchAdminPortal() async {
    final url = Uri.parse(AppStrings.adminPortalUrl);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch admin portal');
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<FirebaseAuthService>(context);
    final UserModel? user = authService.currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('ప్రొఫైల్'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60,
              child: Text(
                user.phoneNumber ?? '',
                style: const TextStyle(fontSize: 20, fontFamily: 'TeluguOne'),
              ),
            ),
            const SizedBox(height: 20),
            Text(user.phoneNumber ?? '', style: const TextStyle(fontSize: 18, fontFamily: 'TeluguOne')),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () => authService.signOut(),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.pink, minimumSize: const Size.fromHeight(48)),
              icon: const Icon(Icons.logout),
              label: Text(AppStrings.logout, style: const TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 20),
            if (user.isAdmin)
              ElevatedButton.icon(
                onPressed: _launchAdminPortal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  minimumSize: const Size.fromHeight(48),
                ),
                icon: const Icon(Icons.admin_panel_settings),
                label: const Text('అడ్మిన్ పోర్టల్', style: TextStyle(fontSize: 16)),
              ),
          ],
        ),
      ),
    );
  }
}
