import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../constants/strings.dart';
import '../models/news_item.dart';
import '../services/firestore_service.dart';
import '../widgets/news_card.dart';
import '../routes.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({Key? key}) : super(key: key);

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final FirestoreService _firestoreService = FirestoreService();

  final List<String> _allCategories = [
    'Politics',
    'Entertainment',
    'Jobs',
    'Sports',
    'Technology',
    'Health',
    'Business',
    'Education',
    'Local',
  ];

  List<String> _selectedCategories = [];
  List<NewsItem> _newsItems = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _selectedCategories.add(_allCategories.first);
    _fetchNews();
  }

  void _fetchNews() {
    setState(() => _loading = true);
    _firestoreService.getNewsStreamByCategories(_selectedCategories).listen((news) {
      setState(() {
        _newsItems = news;
        _loading = false;
      });
    });
  }

  void _onCategoryToggle(String category) {
    setState(() {
      if (_selectedCategories.contains(category)) {
        _selectedCategories.remove(category);
      } else {
        _selectedCategories.add(category);
      }
    });
    _fetchNews();
  }

  void _onNewsTap(NewsItem newsItem) {
    Navigator.of(context).pushNamed(Routes.fullNews, arguments: newsItem);
  }

  Widget _buildCategoryChips() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: _allCategories.map((cat) {
          final selected = _selectedCategories.contains(cat);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: FilterChip(
              label: Text(
                cat,
                style: TextStyle(
                  color: selected ? Colors.white : AppColors.darkGrey,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'TeluguOne',
                ),
              ),
              selected: selected,
              selectedColor: AppColors.pink,
              backgroundColor: AppColors.cardGrey,
              onSelected: (_) => _onCategoryToggle(cat),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
          );
        }).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.categories),
        centerTitle: true,
      ),
      body: Column(
        children: [
          _buildCategoryChips(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _newsItems.isEmpty
                    ? Center(
                        child: Text(
                          'వార్తలు లభించలేదు',
                          style: const TextStyle(
                              fontSize: 16,
                              fontFamily: 'TeluguOne',
                              color: AppColors.lightGrey),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _newsItems.length,
                        itemBuilder: (_, index) {
                          final newsItem = _newsItems[index];
                          return NewsCard(
                            newsItem: newsItem,
                            onTap: () => _onNewsTap(newsItem),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
