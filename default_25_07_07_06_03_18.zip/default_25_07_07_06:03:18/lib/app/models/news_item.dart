import 'package:cloud_firestore/cloud_firestore.dart';

class NewsItem {
  final String id;
  final String title;
  final String content;
  final String category;
  final double latitude;
  final double longitude;
  final String city;
  final List<String> mediaUrls;
  final bool isVideo;
  final Timestamp timestamp;

  NewsItem({
    required this.id,
    required this.title,
    required this.content,
    required this.category,
    required this.latitude,
    required this.longitude,
    required this.city,
    required this.mediaUrls,
    required this.isVideo,
    required this.timestamp,
  });

  factory NewsItem.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return NewsItem(
      id: doc.id,
      title: data['title'] ?? '',
      content: data['content'] ?? '',
      category: data['category'] ?? '',
      latitude: (data['latitude'] ?? 0).toDouble(),
      longitude: (data['longitude'] ?? 0).toDouble(),
      city: data['city'] ?? '',
      mediaUrls: List<String>.from(data['mediaUrls'] ?? []),
      isVideo: data['isVideo'] ?? false,
      timestamp: data['timestamp'] ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'content': content,
      'category': category,
      'latitude': latitude,
      'longitude': longitude,
      'city': city,
      'mediaUrls': mediaUrls,
      'isVideo': isVideo,
      'timestamp': timestamp,
    };
  }
}
