import 'package:firebase_auth/firebase_auth.dart';

class UserModel {
  final String uid;
  final String? phoneNumber;
  final bool isAdmin;

  UserModel({
    required this.uid,
    this.phoneNumber,
    this.isAdmin = false,
  });

  factory UserModel.fromFirebase(User user, {bool admin = false}) {
    return UserModel(
      uid: user.uid,
      phoneNumber: user.phoneNumber,
      isAdmin: admin,
    );
  }
}
