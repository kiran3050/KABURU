import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../constants/strings.dart';

class BottomNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const BottomNavBar({
    Key? key,
    required this.currentIndex,
    required this.onTap,
  }) : super(key: key);

  static const _items = [
    _NavItem(label: AppStrings.home, icon: Icons.home_outlined),
    _NavItem(label: AppStrings.categories, icon: Icons.category_outlined),
    _NavItem(label: AppStrings.videos, icon: Icons.video_library_outlined),
    _NavItem(label: AppStrings.saved, icon: Icons.bookmark_border),
    _NavItem(label: AppStrings.profile, icon: Icons.person_outline),
  ];

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      selectedItemColor: AppColors.pink,
      unselectedItemColor: AppColors.lightGrey,
      currentIndex: currentIndex,
      onTap: onTap,
      type: BottomNavigationBarType.fixed,
      items: _items
          .map(
            (e) => BottomNavigationBarItem(
              icon: Icon(e.icon),
              label: e.label,
              tooltip: e.label,
            ),
          )
          .toList(),
    );
  }
}

class _NavItem {
  final String label;
  final IconData icon;
  const _NavItem({required this.label, required this.icon});
}
