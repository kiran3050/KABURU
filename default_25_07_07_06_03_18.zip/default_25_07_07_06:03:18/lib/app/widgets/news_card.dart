import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/news_item.dart';
import '../constants/colors.dart';

class NewsCard extends StatelessWidget {
  final NewsItem newsItem;
  final VoidCallback onTap;

  const NewsCard({
    Key? key,
    required this.newsItem,
    required this.onTap,
  }) : super(key: key);

  Widget _buildMediaThumbnail() {
    if (newsItem.mediaUrls.isEmpty) {
      return Container(
        height: 130,
        color: AppColors.cardGrey,
        child: const Icon(Icons.newspaper_outlined, size: 64, color: AppColors.lightGrey),
      );
    }
    String thumbUrl = newsItem.mediaUrls.first;
    if (newsItem.isVideo) {
      // Could overlay a play icon on thumbnail
      return Stack(
        alignment: Alignment.center,
        children: [
          CachedNetworkImage(
            imageUrl: thumbUrl,
            height: 130,
            width: double.infinity,
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              height: 130,
              color: AppColors.cardGrey,
            ),
            errorWidget: (context, url, error) => Container(
              height: 130,
              color: AppColors.cardGrey,
              child: const Icon(Icons.error),
            ),
          ),
          const Icon(Icons.play_circle_fill, color: Colors.white, size: 48),
        ],
      );
    }
    return CachedNetworkImage(
      imageUrl: thumbUrl,
      height: 130,
      width: double.infinity,
      fit: BoxFit.cover,
      placeholder: (context, url) => Container(
        height: 130,
        color: AppColors.cardGrey,
      ),
      errorWidget: (context, url, error) => Container(
        height: 130,
        color: AppColors.cardGrey,
        child: const Icon(Icons.error),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(12)), child: _buildMediaThumbnail()),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    margin: const EdgeInsets.only(bottom: 6),
                    decoration: BoxDecoration(
                      color: AppColors.categoryPink.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      newsItem.category,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12),
                    ),
                  ),
                  Text(
                    newsItem.title,
                    style: const TextStyle(
                      fontFamily: 'TeluguOne',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkGrey,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    newsItem.content,
                    style: const TextStyle(
                      fontFamily: 'TeluguOne',
                      fontSize: 14,
                      color: AppColors.lightGrey,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
