import 'package:flutter/material.dart';
import '../helpers/transliteration_helper.dart';

class TransliterationTextField extends StatefulWidget {
  final TextEditingController controller;
  final String labelText;
  final int maxLines;
  final TextInputType keyboardType;

  const TransliterationTextField({
    Key? key,
    required this.controller,
    required this.labelText,
    this.maxLines = 1,
    this.keyboardType = TextInputType.text,
  }) : super(key: key);

  @override
  State<TransliterationTextField> createState() => _TransliterationTextFieldState();
}

class _TransliterationTextFieldState extends State<TransliterationTextField> {
  late final TransliterationHelper _transliterationHelper;
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _transliterationHelper = TransliterationHelper();
    _controller = widget.controller;
    _controller.addListener(_onTextChanged);
  }

  void _onTextChanged() {
    final newText = _controller.text;
    final transliterated = _transliterationHelper.transliterate(newText);
    if (transliterated != newText) {
      final cursorPosition = _controller.selection.baseOffset;
      _controller.value = TextEditingValue(
        text: transliterated,
        selection: TextSelection.collapsed(offset: cursorPosition),
      );
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onTextChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _controller,
      maxLines: widget.maxLines,
      keyboardType: widget.keyboardType,
      decoration: InputDecoration(
        labelText: widget.labelText,
        border: const OutlineInputBorder(),
      ),
    );
  }
}
