import 'package:flutter/material.dart';
import 'app/constants/colors.dart';

final ThemeData kaburuTheme = ThemeData(
  brightness: Brightness.light,
  primaryColor: AppColors.pink,
  scaffoldBackgroundColor: AppColors.greyBackground,
  fontFamily: 'TeluguOne',
  colorScheme: ColorScheme.fromSwatch().copyWith(
    primary: AppColors.pink,
    secondary: AppColors.pink,
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    selectedItemColor: AppColors.pink,
    unselectedItemColor: AppColors.lightGrey,
    showUnselectedLabels: true,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: AppColors.pink,
    foregroundColor: Colors.white,
    elevation: 0,
    centerTitle: true,
    titleTextStyle: TextStyle(
      fontFamily: 'TeluguOne',
      fontWeight: FontWeight.bold,
      fontSize: 22,
    ),
  ),
  cardTheme: CardTheme(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    elevation: 2,
    color: AppColors.white,
  ),
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(color: AppColors.pink, width: 2),
      borderRadius: BorderRadius.circular(8),
    ),
  ),
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: AppColors.pink,
      textStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
      ),
    ),
  ),
);
