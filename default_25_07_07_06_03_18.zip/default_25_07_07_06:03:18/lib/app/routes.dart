import 'package:flutter/material.dart';
import 'app/screens/home_screen.dart';
import 'app/screens/otp_login_screen.dart';
import 'app/screens/full_news_screen.dart';
import 'app/models/news_item.dart';

class Routes {
  static const String otpLogin = '/otpLogin';
  static const String home = '/home';
  static const String fullNews = '/fullNews';

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case otpLogin:
        return MaterialPageRoute(builder: (_) => const OTPLoginScreen());
      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case fullNews:
        final args = settings.arguments;
        if (args is NewsItem) {
          return MaterialPageRoute(builder: (_) => FullNewsScreen(newsItem: args));
        }
        return _errorRoute();
      default:
        return _errorRoute();
    }
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(
        builder: (_) => Scaffold(
              appBar: AppBar(title: const Text('Error')),
              body: const Center(child: Text('Page not found')),
            ));
  }
}
