import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/news_item.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<NewsItem>> getNewsStreamByCityAndCategories(String city, List<String> categories) {
    return _db
        .collection('news')
        .where('city', isEqualTo: city)
        .where('category', whereIn: categories.isEmpty ? ['Politics'] : categories)
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => NewsItem.fromFirestore(doc)).toList());
  }

  Stream<List<NewsItem>> getNewsStreamByCategories(List<String> categories) {
    if (categories.isEmpty) {
      return _db
          .collection('news')
          .orderBy('timestamp', descending: true)
          .snapshots()
          .map((snapshot) => snapshot.docs.map((doc) => NewsItem.fromFirestore(doc)).toList());
    }
    return _db
        .collection('news')
        .where('category', whereIn: categories)
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => NewsItem.fromFirestore(doc)).toList());
  }

  Stream<List<NewsItem>> getVideoNewsStream() {
    return _db
        .collection('news')
        .where('isVideo', isEqualTo: true)
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => NewsItem.fromFirestore(doc)).toList());
  }

  Future<void> addNewsItem(NewsItem news) async {
    await _db.collection('news').doc(news.id).set(news.toFirestore());
  }

  Future<void> updateNewsItem(NewsItem news) async {
    await _db.collection('news').doc(news.id).update(news.toFirestore());
  }

  Future<void> deleteNewsItem(String id) async {
    await _db.collection('news').doc(id).delete();
  }
}
