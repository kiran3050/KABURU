class AppStrings {
  static const String appName = 'కబురు';
  static const String home = 'ఇంటి';
  static const String categories = 'వర్గాలు';
  static const String videos = 'వీడియోలు';
  static const String saved = 'సేవ్ చేసినవి';
  static const String profile = 'ప్రొఫైల్';

  static const String enterPhoneNumber = 'ఫోన్ నెంబర్ నమోదు చేయండి';
  static const String sendOtp = 'OTP పంపండి';
  static const String enterOtp = 'OTP నమోదు చేయండి';
  static const String verifyOtp = 'OTP ధృవీకరించండి';

  static const String newsCategoriesTitle = 'వర్గాలు';

  static const String adminPortalUrl = 'https://console.firebase.google.com/u/0/project/kaburu-admin/';

  static const String savedNews = 'సేవ్ చేసిన వార్తలు';
  static const String logout = 'లోగౌట్ చేయండి';
}
