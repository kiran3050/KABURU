import 'package:flutter/material.dart';

class AppColors {
  static const Color pink = Color(0xFFE91E63);
  static const Color greyBackground = Color(0xFFF5F5F5);
  static const Color darkGrey = Color(0xFF424242);
  static const Color lightGrey = Color(0xFF9E9E9E);
  static const Color cardGrey = Color(0xFFE0E0E0);
  static const Color white = Colors.white;

  // Category colors can extend pink shades or similar
  static const Color categoryPink = Color(0xFFD81B60);
}
