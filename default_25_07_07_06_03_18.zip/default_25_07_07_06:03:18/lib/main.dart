import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';

import 'app/constants/colors.dart';
import 'app/routes.dart';
import 'app/screens/otp_login_screen.dart';
import 'app/screens/home_screen.dart';
import 'app/services/firebase_auth_service.dart';
import 'app/services/notification_service.dart';
import 'app/models/user.dart';
import 'app/theme.dart';
import 'firebase/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await NotificationService().init();

  runApp(const KaburuApp());
}

class KaburuApp extends StatelessWidget {
  const KaburuApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FirebaseAuthService()),
      ],
      child: MaterialApp(
        title: 'KABURU కబురు',
        debugShowCheckedModeBanner: false,
        theme: kaburuTheme,
        onGenerateRoute: Routes.generateRoute,
        home: AnimatedSplashScreen(
          splash: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'కబురు',
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                  color: AppColors.pink,
                  fontFamily: 'TeluguOne',
                ),
              ),
            ],
          ),
          splashIconSize: 150,
          backgroundColor: AppColors.greyBackground,
          splashTransition: SplashTransition.scaleTransition,
          nextScreen: const AuthenticationWrapper(),
          duration: 2000,
        ),
      ),
    );
  }
}

class AuthenticationWrapper extends StatelessWidget {
  const AuthenticationWrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<FirebaseAuthService>(context);
    return StreamBuilder<UserModel?>(
      stream: authService.user,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final user = snapshot.data;
        if (user == null) {
          return const OTPLoginScreen();
        }
        return const HomeScreen();
      },
    );
  }
}
